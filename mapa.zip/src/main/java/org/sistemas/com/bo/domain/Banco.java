package org.sistemas.com.bo.domain;

import java.io.Serializable;

public class Banco implements Serializable{
	
	private static final long serialVersionUID = 399566913704100002L;//si
	
	private int id;
	private String nombre;
	private String telefono;
	private String web;
	
	
	
	public Banco() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getWeb() {
		return web;
	}
	public void setWeb(String web) {
		this.web = web;
	}
	
	

}
