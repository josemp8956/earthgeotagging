package org.sistemas.com.bo.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;  
import javax.faces.context.FacesContext;  
import javax.faces.event.ActionEvent; 

import org.sistemas.com.bo.domain.Banco;
import org.sistemas.com.bo.domain.Coordenada;
import org.sistemas.com.bo.domain.Coordenadai;
import org.sistemas.com.bo.service.UpdsService;

import org.primefaces.event.map.MarkerDragEvent;
import org.primefaces.event.map.OverlaySelectEvent;
import org.primefaces.event.map.PointSelectEvent;
import org.primefaces.model.map.DefaultMapModel;  
import org.primefaces.model.map.LatLng;  
import org.primefaces.model.map.MapModel;

import org.primefaces.model.map.Circle;
import org.primefaces.model.map.DefaultMapModel;
import org.primefaces.model.map.LatLng;
import org.primefaces.model.map.LatLngBounds;
import org.primefaces.model.map.MapModel;
import org.primefaces.model.map.Marker;
import org.primefaces.model.map.Polygon;
import org.primefaces.model.map.Polyline;
import org.primefaces.model.map.Rectangle;
import org.primefaces.push.PushContext;
import org.primefaces.push.PushContextFactory;

import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;
//import org.primefaces.examples.domain.Car;
import org.primefaces.model.SelectableDataModel;

public class MapBean  implements Serializable {  
	//https://joseguerreroa.wordpress.com/2012/10/27/determinacion-de-areas-de-poligonos-irregulares-usando-las-coordenadas-de-sus-vertices-en-un-script-de-python/
	//https://www.mapanet.eu/resources/Script-Distance.htm
	//https://joseguerreroa.wordpress.com/2012/11/13/distancia-entre-dos-puntos-de-la-superficie-terrestre-mediante-la-formula-de-haversine-con-python/
	/*******************SERVICIOS*****************************/		
	private UpdsService updsService;	
	public void setUpdsService(UpdsService updsService)	
	{
		this.updsService = updsService;  		
		
	}	
	public MapBean() {    }  
	/*********************LISTA*************************/
	private List<Coordenada> coordenadas=new ArrayList<Coordenada>();	
	
	public List<Coordenada> getCoordenadas() {
		return coordenadas;
	}
	public void setCoordenadas(List<Coordenada> coordenadas) {
		this.coordenadas = coordenadas;
	}	
    
    /***************************COORDENADA INICIAL*********************************/
    private Coordenadai coordenadaInicial;	 
    private double latitud;
	private double longitud;
	private int idi;
	
	public Coordenadai getCoordenadaInicial() {
		return coordenadaInicial;	}

	public void setCoordenadaInicial(Coordenadai coordenadaInicial) {
		this.coordenadaInicial = coordenadaInicial;
	}	
	public double getLatitud() {
		return latitud;
	}
	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}
	public double getLongitud() {
		return longitud;
	}
	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}
    
    public int getIdi() {
		return idi;
	}
	public void setIdi(int idi) {
		this.idi = idi;
	}
	/***************************PARA CREAR EMPTY MODEL*********************************/
    private MapModel emptyModel;
    private String title;     
    private double lat;       
    private double lng;  
    
    public MapModel getEmptyModel() {  
    	
    	
    	latitud=-19.047908186835446;
		longitud= -65.25962054729462;	
		emptyModel = new DefaultMapModel(); 
		
		List<Coordenadai> coordenadasi=new ArrayList<Coordenadai>();
    	coordenadasi=updsService.getCoordenadasi();
    	Coordenadai coordenada=new Coordenadai();
    	for(Iterator it=coordenadasi.iterator();it.hasNext();)		
		{
			coordenada=(Coordenadai)it.next();
			emptyModel.addOverlay(lineadibujar(coordenada.getId(),coordenada.getTitulo())); 
			
		}
        
		
        return emptyModel;  
    }  
    public String getTitle() {  
        return title;  
    }  
  
    public void setTitle(String title) {  
        this.title = title;  
    }  
  
    public double getLat() {  
        return lat;  
    }  
  
    public void setLat(double lat) {  
        this.lat = lat;  
    }  
  
    public double getLng() {  
        return lng;  
    }  
  
    public void setLng(double lng) {  
        this.lng = lng;  
    }  
    public void addMarker(ActionEvent actionEvent) {  
        Marker marker = new Marker(new LatLng(lat, lng), title);  
        Coordenadai coord=new Coordenadai(lat,lng,title,"linea",0,"","","","","","");
        updsService.insertCoordenadai(coord);
        
        Coordenadai coordi=updsService.getCoordenadaiMover(coord);
        
        coordenadaInicial=updsService.getCoordenadai(coordi.getId());
		latitud=coordenadaInicial.getLat();
		longitud= coordenadaInicial.getLon();
		idi=coordenadaInicial.getId();
		
        emptyModel.addOverlay(marker);   
        crear(null);
        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Marker Added", "Lat:" + lat + ", Lng:" + lng));  
    }  
    public void crear(ActionEvent actionEvent)
    {   
    	
        draggableModel = new DefaultMapModel(); 
        coordenadaInicial=updsService.getCoordenadai(idi);
        selectedCar=coordenadaInicial;
        
	    updsService.insertCoordenada(new Coordenada(selectedCar.getLat(),selectedCar.getLon(),selectedCar.getTitulo(),selectedCar.getId()));
	    latitud=selectedCar.getLat();
	    longitud= selectedCar.getLon();
	    
    	Marker markera = new Marker(new LatLng(selectedCar.getLat(), selectedCar.getLon()), selectedCar.getTitulo());  
    	draggableModel.addOverlay(markera);
    	
    	
       	List<Coordenadai> coordenadasi=new ArrayList<Coordenadai>();
    	coordenadasi=updsService.getCoordenadasi();
    	Coordenadai coordenada=new Coordenadai();
    	for(Iterator it=coordenadasi.iterator();it.hasNext();)		
		{
    		
			coordenada=(Coordenadai)it.next();
    		
    			draggableModel.addOverlay(lineadibujar(coordenada.getId(),coordenada.getTitulo())); 
    		
			
			
		}
    	
    	for(Marker marker : draggableModel.getMarkers()) {  
            marker.setDraggable(true);  
        }  
    	cars=updsService.getCoordenadasi();
   	 mediumCarsModel = new CarDataModel(cars); 
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsMover.xhtml?")).append("faces-redirect=true").toString());
			
    }
    /***************************PARA MOVER DRAGGABLE MODEL*********************************/
    private MapModel draggableModel; 
    public MapModel getDraggableModel() {  
        return draggableModel;  
    } 
    
    
    
    public void mover(ActionEvent actionEvent)
    {   
		
		draggableModel = new DefaultMapModel(); 
		latitud=-19.047908186835446;
		longitud= -65.25962054729462;	
	 
    	List<Coordenadai> coordenadasi=new ArrayList<Coordenadai>();
    	coordenadasi=updsService.getCoordenadasi();
    	
    	Coordenadai coordenada=new Coordenadai();
    	for(Iterator it=coordenadasi.iterator();it.hasNext();)		
		{
			coordenada=(Coordenadai)it.next();
			draggableModel.addOverlay(lineadibujar(coordenada.getId(),coordenada.getTitulo())); 
			
		}
      
    	for(Marker marker : draggableModel.getMarkers()) {  
            marker.setDraggable(true);  
        }  
    	cars=updsService.getCoordenadasi();
    	 mediumCarsModel = new CarDataModel(cars); 
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsMover.xhtml?")).append("faces-redirect=true").toString());
			
    }

    public Polyline lineadibujar(int id, String color)
    {
    	Polyline polyline = new Polyline(); 
    	
    	Coordenada coordenada=new Coordenada();
        coordenadas=updsService.getCoordenadas();
        for(Iterator it=coordenadas.iterator();it.hasNext();)		
    	{
        	coordenada=(Coordenada)it.next();
        	if(coordenada.getIdi()==id)
        	{
        		polyline.getPaths().add(new LatLng(coordenada.getLat(), coordenada.getLon())); 
        	}
        	
    	}   
        //fffc00 amarillo
        //ff0000 rojo
        //001eff azul
        //5aff00 verde
        //00f5fe celeste
        polyline.setStrokeWeight(3); 
        if(color.equals("Amarillo"))
        {
        	polyline.setStrokeColor("#fffc00");
        }
        if(color.equals("Rojo"))
        {
        	polyline.setStrokeColor("#ff0000");
        }
        if(color.equals("Azul"))
        {
        	polyline.setStrokeColor("#001eff");
        }
        if(color.equals("Verde"))
        {
        	polyline.setStrokeColor("#5aff00");
        }
        if(color.equals("Celeste"))
        {
        	polyline.setStrokeColor("#00f5fe");
        }
         
          
        //polyline.setStrokeOpacity(0.7);  
        
    	
    	return polyline;
    }
    public void onMarkerDrag(MarkerDragEvent event) {  
    	Marker  marker = event.getMarker();  
    	 
    	draggableModel = new DefaultMapModel();
    	double km =distanciaCoord(coordenadaInicial.getLat(),coordenadaInicial.getLon(),marker.getLatlng().getLat(),marker.getLatlng().getLng());
    	
    	coordenadaInicial.setLat(marker.getLatlng().getLat());
    	coordenadaInicial.setLon(marker.getLatlng().getLng());
    	coordenadaInicial.setD(coordenadaInicial.getD()+km);
    	coordenadaInicial.setDescr("descr");
    	updsService.updateCoordenadai(coordenadaInicial);
    	
    	Coordenada coord=new Coordenada(marker.getLatlng().getLat(),marker.getLatlng().getLng(),km+"",coordenadaInicial.getId());
        updsService.insertCoordenada(coord);
        
        Marker markera = new Marker(new LatLng(coordenadaInicial.getLat(), coordenadaInicial.getLon()),  "Karaalioglu Parki", "karaalioglu.png", "http://maps.google.com/mapfiles/ms/micons/yellow-dot.png");

    	draggableModel.addOverlay(markera);
    	
    	List<Coordenadai> coordenadasi=new ArrayList<Coordenadai>();
    	coordenadasi=updsService.getCoordenadasi();
    	Coordenadai coordenada=new Coordenadai();
    	for(Iterator it=coordenadasi.iterator();it.hasNext();)		
		{
			coordenada=(Coordenadai)it.next();
			draggableModel.addOverlay(lineadibujar(coordenada.getId(),coordenada.getTitulo())); 
			
		}
    	
        //draggableModel.addOverlay(lineadibujar(selectedCar.getId(),selectedCar.getTitulo())); 
        
        for(Marker markern : draggableModel.getMarkers()) {  
            markern.setDraggable(true);  
        } 
        
        //draggableModel.addOverlay(lineadibujar(selectedCar.getId(),selectedCar.getTitulo())); 
        FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsMover.xhtml?")).append("faces-redirect=true").toString());
        
        //addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Marker Dragged", "Lat:" + marker.getLatlng().getLat() + ", Lng:" + marker.getLatlng().getLng()));
        //addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Marker Dragged", "Lat:" + event. + ", Lng:" + marker.getLatlng().getLng()));  
    }      
    private Marker markerkm;  
    
    
    public Marker getMarkerkm() {
		return markerkm;
	}
	public void setMarkerkm(Marker markerkm) {
		this.markerkm = markerkm;
	}
	public void onMarkerSelect(OverlaySelectEvent event) {  
    	Marker marker = (Marker) event.getOverlay();  
          
    	Coordenadai coord=new Coordenadai(marker.getLatlng().getLat(),marker.getLatlng().getLng(),"","linea",0);
       
    	
        Coordenadai coordi=updsService.getCoordenadaiMover(coord);
        marker.setTitle("Km.: "+coordi.getD());
        marker.setData("mt.: "+coordi.getD()*1000);
        markerkm=marker;
    	addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Trayectoria", "Distancia en Km.:" + coordi.getD()));
    }  
    /***************************PARA DIBUJAR LINEA POLYLINE MODEL*********************************/
    private MapModel polylineModel;  
	 
	public MapModel getPolylineModel() {  
	        return polylineModel;  
	}  
	  
	public void onPolylineSelect(OverlaySelectEvent event) {  
		//event
		//Marker  marker = event.getSource().; 
		DefaultMapModel draggableModela = new DefaultMapModel();
		draggableModela= (DefaultMapModel) event.getOverlay().getData();
		List<Marker>  marker =draggableModel.getMarkers();
	        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Polyline Selected", null));  
	}  
	public void lineas(ActionEvent actionEvent)
    {   
		polylineModel = new DefaultMapModel(); 
        Polyline polyline = new Polyline();  
        Coordenada coordenada=new Coordenada();
        coordenadas=updsService.getCoordenadas();
        for(Iterator it=coordenadas.iterator();it.hasNext();)		
    	{
        	coordenada=(Coordenada)it.next();
        	 polyline.getPaths().add(new LatLng(coordenada.getLat(), coordenada.getLon()));  
        	 
        	 Marker marker = new Marker(new LatLng(coordenada.getLat(), coordenada.getLon()), coordenada.getTitulo());  
        	 polylineModel.addOverlay(marker);
    	}         
        polyline.setStrokeWeight(5);  
        polyline.setStrokeColor("#ff0000");  
        polyline.setStrokeOpacity(0.9);  
          
        polylineModel.addOverlay(polyline);  
        
        latitud=coordenadaInicial.getLat();
	    longitud= coordenadaInicial.getLon();
		
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsLineas.xhtml?")).append("faces-redirect=true").toString());
			
    }
	/***************************LIMPIAR*********************************/
	public void limpiar(ActionEvent actionEvent)
    {   
		
        Coordenada coordenada=new Coordenada();
        coordenadas=updsService.getCoordenadas();
        for(Iterator it=coordenadas.iterator();it.hasNext();)		
    	{
        	coordenada=(Coordenada)it.next();
        	updsService.deleteCoordenada(coordenada);        	
    	}
        
        Coordenada coord=new Coordenada(latitud,longitud,"inicio",idi);
        updsService.insertCoordenada(coord);
          
        emptyModel = new DefaultMapModel();
        lineas(null);
			
    }	
    /************************************************************/
    
    public void addMessage(FacesMessage message) {  
        FacesContext.getCurrentInstance().addMessage(null, message);  
    }  
    
    
    /**************************************************************************************/
    private List<Coordenadai> cars;  
    
    private Coordenadai selectedCar;  
  
    private Coordenadai[] selectedCars;
    private CarDataModel mediumCarsModel;  
    
    private String accion;
    
    public Coordenadai[] getSelectedCars() {  
        return selectedCars;  
    }  
    public void setSelectedCars(Coordenadai[] selectedCars) {  
        this.selectedCars = selectedCars;  
    }  
  
    public Coordenadai getSelectedCar() {  
        return selectedCar;  
    }  
  
    public void setSelectedCar(Coordenadai selectedCar) {  
    	
        this.selectedCar = selectedCar;  
        if(accion.equals("editar"))
        {
        	System.out.println("seleccionado"+selectedCar.getId());
            draggableModel = new DefaultMapModel(); 
            coordenadaInicial=updsService.getCoordenadai(selectedCar.getId());
    	    updsService.insertCoordenada(new Coordenada(coordenadaInicial.getLat(),coordenadaInicial.getLon(),coordenadaInicial.getTitulo(),coordenadaInicial.getId()));
    	    latitud=coordenadaInicial.getLat();
    	    longitud= coordenadaInicial.getLon();
        	Marker markera = new Marker(new LatLng(coordenadaInicial.getLat(), coordenadaInicial.getLon()), coordenadaInicial.getTitulo());  
        	//draggableModel.addOverlay(markera);
        	draggableModel.addOverlay(new Marker(new LatLng(coordenadaInicial.getLat(), coordenadaInicial.getLon()),  "Karaalioglu Parki", "karaalioglu.png", "http://maps.google.com/mapfiles/ms/micons/yellow-dot.png"));
        	
        	 
           	List<Coordenadai> coordenadasi=new ArrayList<Coordenadai>();
        	coordenadasi=updsService.getCoordenadasi();
        	Coordenadai coordenada=new Coordenadai();
        	for(Iterator it=coordenadasi.iterator();it.hasNext();)		
    		{
    			coordenada=(Coordenadai)it.next();
    			draggableModel.addOverlay(lineadibujar(coordenada.getId(),coordenada.getTitulo())); 
    			
    		}
        	
        	for(Marker marker : draggableModel.getMarkers()) {  
                marker.setDraggable(true);  
            }  
        }
        if(accion.equals("eliminar"))
        {
        	Coordenadai coordeliminar=new Coordenadai();
        	coordeliminar.setId(selectedCar.getId());
        	updsService.deleteCoordenadai(coordeliminar);
        	cars=updsService.getCoordenadasi();
       	 mediumCarsModel = new CarDataModel(cars); 
       	 
       	updsService.deleteCoordenada(new Coordenada(2,3,"",selectedCar.getId()));
       	
       	draggableModel = new DefaultMapModel(); 
       	List<Coordenadai> coordenadasi=new ArrayList<Coordenadai>();
    	coordenadasi=updsService.getCoordenadasi();
    	Coordenadai coordenada=new Coordenadai();
    	for(Iterator it=coordenadasi.iterator();it.hasNext();)		
		{
			coordenada=(Coordenadai)it.next();
			draggableModel.addOverlay(lineadibujar(coordenada.getId(),coordenada.getTitulo())); 
			
		}
    	System.out.println("elim");
       	 
        }
        
    	
    	FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsMover.xhtml?")).append("faces-redirect=true").toString());
    }
	public List<Coordenadai> getCars() {
		return cars;
	}
	public void setCars(List<Coordenadai> cars) {
		this.cars = cars;
	}
	public CarDataModel getMediumCarsModel() {
		return mediumCarsModel;
	}
	public void setMediumCarsModel(CarDataModel mediumCarsModel) {
		this.mediumCarsModel = mediumCarsModel;
	}  
	
	
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	/*****************************/

	public void seleccionar(ActionEvent actionEvent)
	{
		
		draggableModel = new DefaultMapModel();
		System.out.println("holaa");
    	for(int i = 0; i < selectedCars.length; i++) {
            //options[i + 1] = new SelectItem(data[i], data[i]);
            System.out.println("dddd"+selectedCars[i].getTitulo()+ " - dfff -"+selectedCars[i].getId());
            draggableModel.addOverlay(lineadibujar(selectedCars[i].getId(),selectedCars[i].getTitulo()));
        }
    	
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsMover.xhtml?")).append("faces-redirect=true").toString());
	}
  
    /*************************distancia*************************/
  
	public static double distanciaCoord(double lat1, double lng1, double lat2, double lng2) {  
        //double radioTierra = 3958.75;//en millas  
        double radioTierra = 6371;//en kil�metros  
        double dLat = Math.toRadians(lat2 - lat1);  
        double dLng = Math.toRadians(lng2 - lng1);  
        double sindLat = Math.sin(dLat / 2);  
        double sindLng = Math.sin(dLng / 2);  
        double va1 = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)  
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));  
        double va2 = 2 * Math.atan2(Math.sqrt(va1), Math.sqrt(1 - va1));  
        double distancia = radioTierra * va2;  
   
        return distancia;  
    }  
	
	 public double distancia (int latitudeOrigem, int longitudeOrigem, int latitudeDestino, int longitudeDestino){

	      double circTerra=40030; // Circunfer�ncia da Terra (em kil�metros)
	      double latitudeO = (double) latitudeOrigem / 3600;
	      double longitudeO = (double) longitudeOrigem / 3600;
	      double latitudeD = (double) latitudeDestino / 3600;
	      double longitudeD = (double) longitudeDestino / 3600;
	      double a = longitudeO - longitudeD;
	      double c = 90.0 - latitudeO;
	      double b = 90.0 - latitudeD;       
	      double aCosA =  (Math.acos(Math.cos(Math.toRadians(b)) * Math.cos(Math.toRadians(c)) + Math.sin(Math.toRadians(b)) * Math.sin(Math.toRadians(c)) * Math.cos(Math.toRadians(a))) * 180 / Math.PI);

	      return(aCosA * circTerra / 360);
	   }
	 
	 /******************************************************/
	 
}  