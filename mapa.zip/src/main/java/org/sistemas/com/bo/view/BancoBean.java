package org.sistemas.com.bo.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.primefaces.event.FlowEvent;
import org.primefaces.event.RowEditEvent;
import org.sistemas.com.bo.domain.Banco;

import org.sistemas.com.bo.service.UpdsService;

public class BancoBean implements Serializable {  
	
	
	/*******************SERVICIOS*****************************/		
	private UpdsService updsService;	
	public void setUpdsService(UpdsService updsService)	
	{this.updsService = updsService;   }	
	/*********************LISTA*************************/

	private List<Banco> registros=new ArrayList<Banco>();
	
	private List<Banco> registrosFiltrado;
	
	
	public List<Banco> getRegistros() {
				
		registros=updsService.getBancos(); 
		return registros;
	}
	public void setRegistros(List<Banco> registros) {
		this.registros = registros;
	}
	
	public List<Banco> getRegistrosFiltrado() {
		return registrosFiltrado;
	}
	public void setRegistrosFiltrado(List<Banco> registrosFiltrado) {
		this.registrosFiltrado = registrosFiltrado;
	}
	
	/**************REDIRECT PAGINA WEB************************/	
	public void registro(ActionEvent actionEvent)
    {   
		registro=new Banco();
		
		
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsRegistrar.xhtml?")).append("faces-redirect=true").toString());
			
    }	
	
	public void actualizar(ActionEvent actionEvent)
    {    			
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsActualizar.xhtml?")).append("faces-redirect=true").toString());
    }
	public void verGrupos(ActionEvent actionEvent)
    {    			
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsGrupos.xhtml?")).append("faces-redirect=true").toString());
    }	
	public void verBuscar(ActionEvent actionEvent)
    {    			
		registros=updsService.getBancos(); 
		FacesContext.getCurrentInstance().getApplication().getNavigationHandler().handleNavigation
    	(FacesContext.getCurrentInstance(), "null", (new StringBuilder
    			("/paginas/bancos/facelets/faceletsBuscar.xhtml?")).append("faces-redirect=true").toString());
		 	
    }
	
	
	/**********************************************************/
	
	private String accion;
	private Banco selectedRegistro;
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	public Banco getSelectedRegistro() {
		return selectedRegistro;
	}
	public void setSelectedRegistro(Banco selectedRegistro) {
		this.selectedRegistro = selectedRegistro;
		if(accion.equals("editar"))
		{
			actualizar(null);
		}
		else
		{
			if(accion.equals("vehiculo"))
			{
				actualizar(null);
			}
			else
			{
				
			}
		}
		
	}
	
	/*******************************************************************/
	
	private Banco registro;  
    private boolean skip;  
	private static Logger logger = Logger.getLogger(BancoBean.class.getName());
	public Banco getRegistro() {
		return registro;
	}
	public void setRegistro(Banco registro) {
		this.registro = registro;
	}
	public boolean isSkip() {
		return skip;
	}
	public void setSkip(boolean skip) {
		this.skip = skip;
	}
	
	
	public String onFlowProcess(FlowEvent event) {  
	    logger.info("Current wizard step:" + event.getOldStep());  
	    logger.info("Next1111 step:" + event.getNewStep());  	          
	        if(skip) {  
	            skip = false;   //reset in case user goes back  
	            return "confirm";  
	        }  
	        else {  
	            return event.getNewStep();  
	        }  
	}  	
	public void save(ActionEvent actionEvent) { 
		
   	updsService.insertBanco(registro);
   	registros=updsService.getBancos(); 
   	verBuscar(null);
   }  
	public void update(ActionEvent actionEvent) {  
		updsService.updateBanco(selectedRegistro);
		verBuscar(null);        
   }  
	public void delete(ActionEvent actionEvent)
    {    			
		updsService.deleteBanco(selectedRegistro);
		registros=updsService.getBancos(); 
		verBuscar(null);   
    }    
	
	/*****************************************/
	

}



